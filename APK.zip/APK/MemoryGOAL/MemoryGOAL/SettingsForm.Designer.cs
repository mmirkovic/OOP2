﻿namespace MemoryGOAL
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
            this.DifficultyLabel = new System.Windows.Forms.Label();
            this.EasyRadioButton = new System.Windows.Forms.RadioButton();
            this.MediumRadioButton = new System.Windows.Forms.RadioButton();
            this.HardRadioButton = new System.Windows.Forms.RadioButton();
            this.CategoryLabel = new System.Windows.Forms.Label();
            this.EPLCheckBox = new System.Windows.Forms.CheckBox();
            this.LaLigaCheckBox = new System.Windows.Forms.CheckBox();
            this.SerieACheckBox = new System.Windows.Forms.CheckBox();
            this.Ligue1CheckBox = new System.Windows.Forms.CheckBox();
            this.BundesligaCheckBox = new System.Windows.Forms.CheckBox();
            this.ChampionsLeagueCheckBox = new System.Windows.Forms.CheckBox();
            this.LETSGOButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.CardsLabel = new System.Windows.Forms.Label();
            this.CardsCheckBox = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.CustomRadioButton = new System.Windows.Forms.RadioButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.CustomTrackBar = new System.Windows.Forms.TrackBar();
            this.CustomBrojParovaTextBox = new System.Windows.Forms.TextBox();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.BackButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // DifficultyLabel
            // 
            this.DifficultyLabel.AutoSize = true;
            this.DifficultyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DifficultyLabel.Location = new System.Drawing.Point(19, 20);
            this.DifficultyLabel.Name = "DifficultyLabel";
            this.DifficultyLabel.Size = new System.Drawing.Size(142, 20);
            this.DifficultyLabel.TabIndex = 0;
            this.DifficultyLabel.Text = "Select difficulty: ";
            // 
            // EasyRadioButton
            // 
            this.EasyRadioButton.AutoSize = true;
            this.EasyRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EasyRadioButton.Location = new System.Drawing.Point(73, 57);
            this.EasyRadioButton.Name = "EasyRadioButton";
            this.EasyRadioButton.Size = new System.Drawing.Size(59, 22);
            this.EasyRadioButton.TabIndex = 1;
            this.EasyRadioButton.Text = "Easy";
            this.EasyRadioButton.UseVisualStyleBackColor = true;
            this.EasyRadioButton.CheckedChanged += new System.EventHandler(this.EasyRadioButton_CheckedChanged);
            // 
            // MediumRadioButton
            // 
            this.MediumRadioButton.AutoSize = true;
            this.MediumRadioButton.Checked = true;
            this.MediumRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MediumRadioButton.Location = new System.Drawing.Point(204, 57);
            this.MediumRadioButton.Name = "MediumRadioButton";
            this.MediumRadioButton.Size = new System.Drawing.Size(79, 22);
            this.MediumRadioButton.TabIndex = 2;
            this.MediumRadioButton.TabStop = true;
            this.MediumRadioButton.Text = "Medium";
            this.MediumRadioButton.UseVisualStyleBackColor = true;
            this.MediumRadioButton.CheckedChanged += new System.EventHandler(this.MediumRadioButton_CheckedChanged);
            // 
            // HardRadioButton
            // 
            this.HardRadioButton.AutoSize = true;
            this.HardRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.HardRadioButton.Location = new System.Drawing.Point(345, 57);
            this.HardRadioButton.Name = "HardRadioButton";
            this.HardRadioButton.Size = new System.Drawing.Size(58, 22);
            this.HardRadioButton.TabIndex = 3;
            this.HardRadioButton.Text = "Hard";
            this.HardRadioButton.UseVisualStyleBackColor = true;
            this.HardRadioButton.CheckedChanged += new System.EventHandler(this.HardRadioButton_CheckedChanged);
            // 
            // CategoryLabel
            // 
            this.CategoryLabel.AutoSize = true;
            this.CategoryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CategoryLabel.Location = new System.Drawing.Point(19, 151);
            this.CategoryLabel.Name = "CategoryLabel";
            this.CategoryLabel.Size = new System.Drawing.Size(138, 20);
            this.CategoryLabel.TabIndex = 4;
            this.CategoryLabel.Text = "Select leagues: ";
            // 
            // EPLCheckBox
            // 
            this.EPLCheckBox.AutoSize = true;
            this.EPLCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EPLCheckBox.Location = new System.Drawing.Point(23, 197);
            this.EPLCheckBox.Name = "EPLCheckBox";
            this.EPLCheckBox.Size = new System.Drawing.Size(131, 22);
            this.EPLCheckBox.TabIndex = 5;
            this.EPLCheckBox.Text = "Premier League";
            this.EPLCheckBox.UseVisualStyleBackColor = true;
            this.EPLCheckBox.CheckedChanged += new System.EventHandler(this.EPLCheckBox_CheckedChanged);
            // 
            // LaLigaCheckBox
            // 
            this.LaLigaCheckBox.AutoSize = true;
            this.LaLigaCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LaLigaCheckBox.Location = new System.Drawing.Point(23, 271);
            this.LaLigaCheckBox.Name = "LaLigaCheckBox";
            this.LaLigaCheckBox.Size = new System.Drawing.Size(74, 22);
            this.LaLigaCheckBox.TabIndex = 6;
            this.LaLigaCheckBox.Text = "La Liga";
            this.LaLigaCheckBox.UseVisualStyleBackColor = true;
            this.LaLigaCheckBox.CheckedChanged += new System.EventHandler(this.LaLigaCheckBox_CheckedChanged);
            // 
            // SerieACheckBox
            // 
            this.SerieACheckBox.AutoSize = true;
            this.SerieACheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.SerieACheckBox.Location = new System.Drawing.Point(270, 197);
            this.SerieACheckBox.Name = "SerieACheckBox";
            this.SerieACheckBox.Size = new System.Drawing.Size(74, 22);
            this.SerieACheckBox.TabIndex = 7;
            this.SerieACheckBox.Text = "Serie A";
            this.SerieACheckBox.UseVisualStyleBackColor = true;
            this.SerieACheckBox.CheckedChanged += new System.EventHandler(this.SerieACheckBox_CheckedChanged);
            // 
            // Ligue1CheckBox
            // 
            this.Ligue1CheckBox.AutoSize = true;
            this.Ligue1CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Ligue1CheckBox.Location = new System.Drawing.Point(270, 271);
            this.Ligue1CheckBox.Name = "Ligue1CheckBox";
            this.Ligue1CheckBox.Size = new System.Drawing.Size(74, 22);
            this.Ligue1CheckBox.TabIndex = 8;
            this.Ligue1CheckBox.Text = "Ligue 1";
            this.Ligue1CheckBox.UseVisualStyleBackColor = true;
            this.Ligue1CheckBox.CheckedChanged += new System.EventHandler(this.Ligue1CheckBox_CheckedChanged);
            // 
            // BundesligaCheckBox
            // 
            this.BundesligaCheckBox.AutoSize = true;
            this.BundesligaCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BundesligaCheckBox.Location = new System.Drawing.Point(23, 347);
            this.BundesligaCheckBox.Name = "BundesligaCheckBox";
            this.BundesligaCheckBox.Size = new System.Drawing.Size(99, 22);
            this.BundesligaCheckBox.TabIndex = 9;
            this.BundesligaCheckBox.Text = "Bundesliga";
            this.BundesligaCheckBox.UseVisualStyleBackColor = true;
            this.BundesligaCheckBox.CheckedChanged += new System.EventHandler(this.BundesligaCheckBox_CheckedChanged);
            // 
            // ChampionsLeagueCheckBox
            // 
            this.ChampionsLeagueCheckBox.AutoSize = true;
            this.ChampionsLeagueCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ChampionsLeagueCheckBox.Location = new System.Drawing.Point(257, 347);
            this.ChampionsLeagueCheckBox.Name = "ChampionsLeagueCheckBox";
            this.ChampionsLeagueCheckBox.Size = new System.Drawing.Size(155, 22);
            this.ChampionsLeagueCheckBox.TabIndex = 10;
            this.ChampionsLeagueCheckBox.Text = "Champions League";
            this.ChampionsLeagueCheckBox.UseVisualStyleBackColor = true;
            this.ChampionsLeagueCheckBox.CheckedChanged += new System.EventHandler(this.ChampionsLeagueCheckBox_CheckedChanged);
            // 
            // LETSGOButton
            // 
            this.LETSGOButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LETSGOButton.Location = new System.Drawing.Point(178, 486);
            this.LETSGOButton.Name = "LETSGOButton";
            this.LETSGOButton.Size = new System.Drawing.Size(153, 63);
            this.LETSGOButton.TabIndex = 11;
            this.LETSGOButton.Text = "LET\'S GO";
            this.LETSGOButton.UseVisualStyleBackColor = true;
            this.LETSGOButton.Click += new System.EventHandler(this.LETSGOButton_Click_1);
            this.LETSGOButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LETSGOButton_Click);
           
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(132, 257);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.LaLigaCheckBox_Checked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(383, 184);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.SerieACheckBox_Checked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(128, 335);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(76, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.BundesligaCheckBox_Checked);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(411, 335);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(76, 48);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.ChampionsLeagueCheckBox_Checked);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(383, 257);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(76, 48);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.Ligue1CheckBox_Checked);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(153, 184);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(76, 48);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 17;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.EPLCheckBox_Checked);
            // 
            // CardsLabel
            // 
            this.CardsLabel.AutoSize = true;
            this.CardsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CardsLabel.Location = new System.Drawing.Point(19, 416);
            this.CardsLabel.Name = "CardsLabel";
            this.CardsLabel.Size = new System.Drawing.Size(161, 20);
            this.CardsLabel.TabIndex = 18;
            this.CardsLabel.Text = "Or play with cards: ";
            // 
            // CardsCheckBox
            // 
            this.CardsCheckBox.AutoSize = true;
            this.CardsCheckBox.Location = new System.Drawing.Point(189, 422);
            this.CardsCheckBox.Name = "CardsCheckBox";
            this.CardsCheckBox.Size = new System.Drawing.Size(15, 14);
            this.CardsCheckBox.TabIndex = 19;
            this.CardsCheckBox.UseVisualStyleBackColor = true;
            this.CardsCheckBox.CheckedChanged += new System.EventHandler(this.CardsCheckBox_CheckedChanged);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(231, 403);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(76, 48);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 20;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.CardsCheckBox_Checked);
            // 
            // CustomRadioButton
            // 
            this.CustomRadioButton.AutoSize = true;
            this.CustomRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CustomRadioButton.Location = new System.Drawing.Point(132, 104);
            this.CustomRadioButton.Name = "CustomRadioButton";
            this.CustomRadioButton.Size = new System.Drawing.Size(79, 22);
            this.CustomRadioButton.TabIndex = 21;
            this.CustomRadioButton.Text = "Custom";
            this.CustomRadioButton.UseVisualStyleBackColor = true;
            this.CustomRadioButton.CheckedChanged += new System.EventHandler(this.CustomRadioButton_CheckedChanged);
            this.CustomRadioButton.MouseHover += new System.EventHandler(this.CustomRadioButton_MouseHover);
            // 
            // CustomTrackBar
            // 
            this.CustomTrackBar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CustomTrackBar.Enabled = false;
            this.CustomTrackBar.Location = new System.Drawing.Point(214, 104);
            this.CustomTrackBar.Maximum = 15;
            this.CustomTrackBar.Minimum = 1;
            this.CustomTrackBar.Name = "CustomTrackBar";
            this.CustomTrackBar.Size = new System.Drawing.Size(171, 45);
            this.CustomTrackBar.TabIndex = 22;
            this.CustomTrackBar.Tag = "";
            this.CustomTrackBar.Value = 8;
            this.CustomTrackBar.Scroll += new System.EventHandler(this.CustomTrackBar_Scroll);
            // 
            // CustomBrojParovaTextBox
            // 
            this.CustomBrojParovaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CustomBrojParovaTextBox.Location = new System.Drawing.Point(391, 104);
            this.CustomBrojParovaTextBox.Name = "CustomBrojParovaTextBox";
            this.CustomBrojParovaTextBox.ReadOnly = true;
            this.CustomBrojParovaTextBox.Size = new System.Drawing.Size(21, 24);
            this.CustomBrojParovaTextBox.TabIndex = 23;
            this.CustomBrojParovaTextBox.Text = "8";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BackButton.Location = new System.Drawing.Point(23, 496);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(74, 43);
            this.BackButton.TabIndex = 24;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 577);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.CustomBrojParovaTextBox);
            this.Controls.Add(this.CustomTrackBar);
            this.Controls.Add(this.CustomRadioButton);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.CardsCheckBox);
            this.Controls.Add(this.CardsLabel);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LETSGOButton);
            this.Controls.Add(this.ChampionsLeagueCheckBox);
            this.Controls.Add(this.BundesligaCheckBox);
            this.Controls.Add(this.Ligue1CheckBox);
            this.Controls.Add(this.SerieACheckBox);
            this.Controls.Add(this.LaLigaCheckBox);
            this.Controls.Add(this.EPLCheckBox);
            this.Controls.Add(this.CategoryLabel);
            this.Controls.Add(this.HardRadioButton);
            this.Controls.Add(this.MediumRadioButton);
            this.Controls.Add(this.EasyRadioButton);
            this.Controls.Add(this.DifficultyLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label DifficultyLabel;
        public System.Windows.Forms.RadioButton EasyRadioButton;
        public System.Windows.Forms.RadioButton MediumRadioButton;
        public System.Windows.Forms.RadioButton HardRadioButton;
        public System.Windows.Forms.Label CategoryLabel;
        public System.Windows.Forms.CheckBox EPLCheckBox;
        public System.Windows.Forms.CheckBox LaLigaCheckBox;
        public System.Windows.Forms.CheckBox SerieACheckBox;
        public System.Windows.Forms.CheckBox Ligue1CheckBox;
        public System.Windows.Forms.CheckBox BundesligaCheckBox;
        public System.Windows.Forms.CheckBox ChampionsLeagueCheckBox;
        private System.Windows.Forms.Button LETSGOButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.Label CardsLabel;
        public System.Windows.Forms.CheckBox CardsCheckBox;
        public System.Windows.Forms.PictureBox pictureBox7;
        public System.Windows.Forms.RadioButton CustomRadioButton;
        public System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.TrackBar CustomTrackBar;
        public System.Windows.Forms.TextBox CustomBrojParovaTextBox;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.Button BackButton;
    }
}