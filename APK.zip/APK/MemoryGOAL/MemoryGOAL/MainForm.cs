﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

namespace MemoryGOAL
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
      

        }
      



        int duration = 0;
       
        public void timer1_Tick(object sender, EventArgs e)
        {
            duration++;
            MjeracTextBox.Text = duration.ToString();
        }

        public void Start_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();

        }

//mjenja se slika buttona kod tajmera ovisno jel ide timer ili ne
        public void Pause_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                PauseButton.Image = MemoryGOAL.Properties.Resources.playbutton;
                timer1.Enabled = false;

            }

            else
            {
                PauseButton.Image = MemoryGOAL.Properties.Resources.pausebutton;
                timer1.Enabled = true;
            }
        }
 //end    


        public void PLAYButton_Click(object sender, EventArgs e)
        {
            foreach (PictureBox picture in panelSlika.Controls)
            {
                picture.Image = Properties.Resources.pausebutton;
            }

            pictureBox1.Load("SLIKE/KLUBOVI/eng/bou.png");

            //if (settingsForm.CardsCheckBox.Checked == true || settingsForm.LaLigaCheckBox.Checked == true || settingsForm.EPLCheckBox.Checked == true || settingsForm.BundesligaCheckBox.Checked == true || settingsForm.ChampionsLeagueCheckBox.Checked == true || settingsForm.SerieACheckBox.Checked == true || settingsForm.Ligue1CheckBox.Checked == true)
            //{
            //    timer1.Enabled = true;
            //    timer1.Start();

            //    PauseButton.Image = MemoryGOAL.Properties.Resources.pausebutton;

            //}










        }



        private void ExitMain_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
