﻿namespace MemoryGOAL
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MemoryGOALLabel = new System.Windows.Forms.Label();
            this.ABOUTButton = new System.Windows.Forms.Button();
            this.PLAYButton = new System.Windows.Forms.Button();
            this.HighscoreButton = new System.Windows.Forms.Button();
            this.ExitStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MemoryGOALLabel
            // 
            this.MemoryGOALLabel.AutoSize = true;
            this.MemoryGOALLabel.Font = new System.Drawing.Font("Monotype Corsiva", 72F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MemoryGOALLabel.ForeColor = System.Drawing.Color.Blue;
            this.MemoryGOALLabel.Location = new System.Drawing.Point(101, 28);
            this.MemoryGOALLabel.Name = "MemoryGOALLabel";
            this.MemoryGOALLabel.Size = new System.Drawing.Size(573, 117);
            this.MemoryGOALLabel.TabIndex = 31;
            this.MemoryGOALLabel.Text = "MemoryGOAL";
            // 
            // ABOUTButton
            // 
            this.ABOUTButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ABOUTButton.Location = new System.Drawing.Point(303, 408);
            this.ABOUTButton.Name = "ABOUTButton";
            this.ABOUTButton.Size = new System.Drawing.Size(207, 74);
            this.ABOUTButton.TabIndex = 30;
            this.ABOUTButton.Text = "ABOUT";
            this.ABOUTButton.UseVisualStyleBackColor = true;
            this.ABOUTButton.Click += new System.EventHandler(this.ABOUTButton_Click);
            // 
            // PLAYButton
            // 
            this.PLAYButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PLAYButton.ForeColor = System.Drawing.Color.Red;
            this.PLAYButton.Location = new System.Drawing.Point(303, 186);
            this.PLAYButton.Name = "PLAYButton";
            this.PLAYButton.Size = new System.Drawing.Size(207, 74);
            this.PLAYButton.TabIndex = 29;
            this.PLAYButton.Text = "PLAY";
            this.PLAYButton.UseVisualStyleBackColor = true;
            this.PLAYButton.Click += new System.EventHandler(this.PLAYButton_Click);
            // 
            // HighscoreButton
            // 
            this.HighscoreButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.HighscoreButton.Location = new System.Drawing.Point(303, 296);
            this.HighscoreButton.Name = "HighscoreButton";
            this.HighscoreButton.Size = new System.Drawing.Size(207, 74);
            this.HighscoreButton.TabIndex = 32;
            this.HighscoreButton.Text = "HIGHSCORES";
            this.HighscoreButton.UseVisualStyleBackColor = true;
            this.HighscoreButton.Click += new System.EventHandler(this.HighscoreButton_Click);
            // 
            // ExitStart
            // 
            this.ExitStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ExitStart.Location = new System.Drawing.Point(681, 514);
            this.ExitStart.Name = "ExitStart";
            this.ExitStart.Size = new System.Drawing.Size(102, 48);
            this.ExitStart.TabIndex = 33;
            this.ExitStart.Text = "EXIT";
            this.ExitStart.UseVisualStyleBackColor = true;
            this.ExitStart.Click += new System.EventHandler(this.ExitStart_Click);
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 574);
            this.Controls.Add(this.ExitStart);
            this.Controls.Add(this.HighscoreButton);
            this.Controls.Add(this.MemoryGOALLabel);
            this.Controls.Add(this.ABOUTButton);
            this.Controls.Add(this.PLAYButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "StartForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StartForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label MemoryGOALLabel;
        public System.Windows.Forms.Button ABOUTButton;
        public System.Windows.Forms.Button PLAYButton;
        public System.Windows.Forms.Button HighscoreButton;
        public System.Windows.Forms.Button ExitStart;
    }
}