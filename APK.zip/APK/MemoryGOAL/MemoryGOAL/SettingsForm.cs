﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MemoryGOAL
{
    public partial class SettingsForm : Form 
    {
        public SettingsForm()
        {
            InitializeComponent();
        }

     

    public void LETSGOButton_Click(object sender, EventArgs e)
        {
            //save u xml...info klasa ostalo
            try
            {
                Podaci info = new Podaci();
                info.Easy = EasyRadioButton.ToString();
                info.Medium = MediumRadioButton.ToString();
                info.Hard = HardRadioButton.ToString();

                info.Custom = CustomRadioButton.ToString();             
                info.CustomBrojParova = CustomBrojParovaTextBox.ToString();

                info.EPL = EPLCheckBox.ToString();
                info.Ligue1 = Ligue1CheckBox.ToString();
                info.LaLiga = LaLigaCheckBox.ToString();
                info.SerieA = SerieACheckBox.ToString();
                info.Bundesliga = BundesligaCheckBox.ToString();
                info.ChampionsLeague = ChampionsLeagueCheckBox.ToString();
                info.Cards = CardsCheckBox.ToString();

                SpremiPostavke.Spremi(info, "postavke.xml");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MainForm mainForm = new MainForm();
            mainForm.Show();


           

            MessageBox.Show("Settings confirmed, press PLAY to start." + "\n" + "(After you press it the timer will start counting!)", "Let's go");

            this.Close();






            //StartForm letsgo = new StartForm();
            //letsgo.Show();

            //letsgo.timer1.Enabled = true;
            //letsgo.timer1.Start();

            //letsgo.PauseButton.Image = MemoryGOAL.Properties.Resources.pausebutton;
            //letsgo.MemoryGOALLabel.Visible = false;

        }

        private void EasyRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (EasyRadioButton.Checked)
            {
                CustomTrackBar.Enabled = false;                          //da se ne moze birat broj parova dok custom nije odabran
            }
        }


        private void MediumRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (MediumRadioButton.Checked)
            {
                CustomTrackBar.Enabled = false;                           //da se ne moze birat broj parova dok custom nije odabran
            }
        }

        private void HardRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (HardRadioButton.Checked)
            {
                CustomTrackBar.Enabled = false;                             //da se ne moze birat broj parova dok custom nije odabran
            }
        }

        private void CustomRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (CustomRadioButton.Checked)
            {
                CustomTrackBar.Enabled = true;                          //da se ne moze birat broj parova dok custom nije odabran
            }
        }

        private void CustomRadioButton_MouseHover(object sender, EventArgs e)
        {
                        
              toolTip1.SetToolTip(CustomRadioButton, "Select a number of pairs to appear."); 
        
         }

//ovo dole je da radi klikanje na zastave 

        private void CardsCheckBox_Checked(object sender, EventArgs e)
        {
            if (CardsCheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;
            }
            else CardsCheckBox.Checked = true;
            
        }

        private void BundesligaCheckBox_Checked(object sender, EventArgs e)
        {
            if (BundesligaCheckBox.Checked == true)
            {
                BundesligaCheckBox.Checked = false;
            }
            else BundesligaCheckBox.Checked = true;
        }

        public void LaLigaCheckBox_Checked(object sender, EventArgs e)
        {
            if (LaLigaCheckBox.Checked == true)
            {
                LaLigaCheckBox.Checked = false;
            }
            else LaLigaCheckBox.Checked = true;
        }

        private void EPLCheckBox_Checked(object sender, EventArgs e)
        {
            if (EPLCheckBox.Checked == true)
            {
                EPLCheckBox.Checked = false;
            }
            else EPLCheckBox.Checked = true;
        }

        private void SerieACheckBox_Checked(object sender, EventArgs e)
        {
            if (SerieACheckBox.Checked == true)
            {
                SerieACheckBox.Checked = false;
            }
            else SerieACheckBox.Checked = true;
        }

        private void Ligue1CheckBox_Checked(object sender, EventArgs e)
        {
            if (Ligue1CheckBox.Checked == true)
            {
                Ligue1CheckBox.Checked = false;
            }
            else Ligue1CheckBox.Checked = true;
        }

        private void ChampionsLeagueCheckBox_Checked(object sender, EventArgs e)
        {
            if (ChampionsLeagueCheckBox.Checked == true)
            {
                ChampionsLeagueCheckBox.Checked = false;
            }
            else ChampionsLeagueCheckBox.Checked = true;
        }

//end

   
            
//ovo je da ne mogu karte i klubovi skupa bit odabrani            
                    
        private void CardsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (CardsCheckBox.Checked == true)
            {
                EPLCheckBox.Checked = false;
                SerieACheckBox.Checked = false;
                Ligue1CheckBox.Checked = false;
                BundesligaCheckBox.Checked = false;
                LaLigaCheckBox.Checked = false;
                ChampionsLeagueCheckBox.Checked = false;

            }
        }

        private void EPLCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (EPLCheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;
               

            }
        }

        private void LaLigaCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (LaLigaCheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;


            }
        }

        private void SerieACheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (SerieACheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;


            }
        }

        private void Ligue1CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Ligue1CheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;


            }
        }

        private void BundesligaCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (BundesligaCheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;


            }
        }

        private void ChampionsLeagueCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (ChampionsLeagueCheckBox.Checked == true)
            {
                CardsCheckBox.Checked = false;


            }
        }
//enddd



        private void CustomTrackBar_Scroll(object sender, EventArgs e)
        {
            
            CustomBrojParovaTextBox.Text = CustomTrackBar.Value.ToString();              // Pokazuje odabranu vrijednost za broj parova
        }

        private void LETSGOButton_MouseHover(object sender, EventArgs e)
        {
            toolTip2.SetToolTip(LETSGOButton, "After pressing this button the timer will start counting.");
        }

        private void LETSGOButton_Click_1(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            StartForm back = new StartForm();
            back.Show();
            this.Close();
        }

    }

}
