﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.IO;

namespace MemoryGOAL
{
    class SpremiPostavke
    {
        public static void Spremi(object obj,string datoteka)
        {
            XmlSerializer sr = new XmlSerializer(obj.GetType());
            TextWriter writer = new StreamWriter(datoteka);
            sr.Serialize(writer, obj);
            writer.Close();
        }
    }
}
