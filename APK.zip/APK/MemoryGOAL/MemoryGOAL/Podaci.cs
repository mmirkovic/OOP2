﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemoryGOAL
{
    public class Podaci
    {
        private string data1;
        private string data2;                           //easy,meidium,hard buttoni
        private string data3;

        private string data4;                            //custom
        private string data6;

        private string data7;
        private string data8;
        private string data9;
        private string data10;                   //klubovi
        private string data11;
        private string data12;

        private string data13;           //cards
        


        public string Easy
        {
            get { return data1; }
            set { data1 = value; }
        }

        public string Medium
        {
            get { return data2; }
            set { data2 = value; }
        }

        public string Hard
        {
            get { return data3; }
            set { data3 = value; }
        }

        //

        public string Custom
        {
            get { return data4; }
            set { data4 = value; }
        }
      
        public string CustomBrojParova
        {
            get { return data6; }
            set { data6 = value; }
        }
        
        //
        
        public string EPL
        {
            get { return data7; }
            set { data7 = value; }
        }
        public string Ligue1
        {
            get { return data8; }
            set { data8 = value; }
        }
        public string LaLiga
        {
            get { return data9; }
            set { data9 = value; }
        }
        public string SerieA
        {
            get { return data10; }
            set { data10 = value; }
        }
        public string Bundesliga
        {
            get { return data11; }
            set { data11 = value; }
        }
        public string ChampionsLeague
        {
            get { return data12; }
            set { data12 = value; }
        }
        public string Cards
        {
            get { return data13; }
            set { data13 = value; }
        }
    }
    
}
