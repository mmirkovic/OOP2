using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MemoryGame
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class SettingsForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox chkFitToSize;
		private System.Windows.Forms.CheckBox chkAspectRatio;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnChange;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label txtNrButtonsY;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox comboNrButtonsX;
		private System.Windows.Forms.ComboBox comboNrButtonsY;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtBackside;
		private System.Windows.Forms.ComboBox comboSecondsShow;
		private System.ComponentModel.Container components = null;

		private DirectoryForm directoryForm;
		private System.Windows.Forms.Button btnOK2;
		private System.Windows.Forms.ListBox listDirectories;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.RadioButton optShow;
		private System.Windows.Forms.RadioButton optRemove;
		private Settings settings;
		private System.Windows.Forms.CheckBox chkShowMessageBox;

		private System.Windows.Forms.Form parentForm = null; // referenz auf parent window

		public SettingsForm(Settings settings, Form parentForm)
		{
			// Required for Windows Form Designer support
			InitializeComponent();
			// my code
			this.parentForm = parentForm; // f�r focus
			directoryForm = new DirectoryForm(this);
			this.settings = settings;
			this.chkAspectRatio.Checked = settings.AspectRatio;
			this.chkFitToSize.Checked = settings.FitToSize;
			this.txtBackside.Text = settings.ButtonText;
			this.comboNrButtonsX.Text = settings.NrButtonsX.ToString();
			this.comboNrButtonsY.Text = settings.NrButtonsY.ToString();
			this.comboSecondsShow.Text = settings.SecondsShow.ToString();
			this.optRemove.Checked = settings.FoundPairsRemove;
			this.optShow.Checked = !settings.FoundPairsRemove;
			this.listDirectories.Items.Clear();
			if (settings.Dirs != null) 
			{
				listDirectories.Items.AddRange(settings.Dirs);
			}
			this.chkShowMessageBox.Checked = settings.ShowPlayerChange;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SettingsForm));
			this.comboSecondsShow = new System.Windows.Forms.ComboBox();
			this.btnChange = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.optRemove = new System.Windows.Forms.RadioButton();
			this.txtNrButtonsY = new System.Windows.Forms.Label();
			this.chkFitToSize = new System.Windows.Forms.CheckBox();
			this.chkShowMessageBox = new System.Windows.Forms.CheckBox();
			this.btnAdd = new System.Windows.Forms.Button();
			this.txtBackside = new System.Windows.Forms.TextBox();
			this.btnCancel = new System.Windows.Forms.Button();
			this.comboNrButtonsY = new System.Windows.Forms.ComboBox();
			this.comboNrButtonsX = new System.Windows.Forms.ComboBox();
			this.btnRemove = new System.Windows.Forms.Button();
			this.listDirectories = new System.Windows.Forms.ListBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chkAspectRatio = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.optShow = new System.Windows.Forms.RadioButton();
			this.btnOK2 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// comboSecondsShow
			// 
			this.comboSecondsShow.DropDownWidth = 48;
			this.comboSecondsShow.Items.AddRange(new object[] {
																  "0",
																  "1",
																  "2",
																  "3",
																  "4",
																  "5",
																  "6",
																  "7",
																  "8",
																  "9",
																  "10"});
			this.comboSecondsShow.Location = new System.Drawing.Point(88, 45);
			this.comboSecondsShow.Name = "comboSecondsShow";
			this.comboSecondsShow.Size = new System.Drawing.Size(48, 21);
			this.comboSecondsShow.TabIndex = 9;
			// 
			// btnChange
			// 
			this.btnChange.Location = new System.Drawing.Point(256, 16);
			this.btnChange.Name = "btnChange";
			this.btnChange.Size = new System.Drawing.Size(56, 24);
			this.btnChange.TabIndex = 3;
			this.btnChange.Text = "Change";
			this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(136, 48);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(128, 16);
			this.label4.TabIndex = 6;
			this.label4.Text = "seconds before playing";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 72);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(144, 16);
			this.label5.TabIndex = 10;
			this.label5.Text = "Text on backside of cards:";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 96);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 16);
			this.label6.TabIndex = 12;
			this.label6.Text = "Found pairs:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 24);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(152, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Number of cards in playfield:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Show cards";
			// 
			// optRemove
			// 
			this.optRemove.Location = new System.Drawing.Point(168, 96);
			this.optRemove.Name = "optRemove";
			this.optRemove.Size = new System.Drawing.Size(64, 16);
			this.optRemove.TabIndex = 14;
			this.optRemove.Text = "remove";
			// 
			// txtNrButtonsY
			// 
			this.txtNrButtonsY.Location = new System.Drawing.Point(216, 24);
			this.txtNrButtonsY.Name = "txtNrButtonsY";
			this.txtNrButtonsY.Size = new System.Drawing.Size(16, 16);
			this.txtNrButtonsY.TabIndex = 2;
			this.txtNrButtonsY.Text = "x";
			// 
			// chkFitToSize
			// 
			this.chkFitToSize.Location = new System.Drawing.Point(16, 24);
			this.chkFitToSize.Name = "chkFitToSize";
			this.chkFitToSize.Size = new System.Drawing.Size(96, 16);
			this.chkFitToSize.TabIndex = 0;
			this.chkFitToSize.Text = "Fit To Size";
			// 
			// chkShowMessageBox
			// 
			this.chkShowMessageBox.Location = new System.Drawing.Point(16, 120);
			this.chkShowMessageBox.Name = "chkShowMessageBox";
			this.chkShowMessageBox.Size = new System.Drawing.Size(240, 16);
			this.chkShowMessageBox.TabIndex = 15;
			this.chkShowMessageBox.Text = "Show Message Box when player changes";
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(256, 56);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(56, 24);
			this.btnAdd.TabIndex = 7;
			this.btnAdd.Text = "Add";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// txtBackside
			// 
			this.txtBackside.Location = new System.Drawing.Point(160, 69);
			this.txtBackside.Name = "txtBackside";
			this.txtBackside.Size = new System.Drawing.Size(120, 20);
			this.txtBackside.TabIndex = 11;
			this.txtBackside.Text = "";
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(176, 352);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(72, 24);
			this.btnCancel.TabIndex = 1;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// comboNrButtonsY
			// 
			this.comboNrButtonsY.DropDownWidth = 48;
			this.comboNrButtonsY.Items.AddRange(new object[] {
																 "2",
																 "3",
																 "4",
																 "5",
																 "6",
																 "7",
																 "8",
																 "9",
																 "10"});
			this.comboNrButtonsY.Location = new System.Drawing.Point(232, 24);
			this.comboNrButtonsY.Name = "comboNrButtonsY";
			this.comboNrButtonsY.Size = new System.Drawing.Size(48, 21);
			this.comboNrButtonsY.TabIndex = 8;
			// 
			// comboNrButtonsX
			// 
			this.comboNrButtonsX.DropDownWidth = 48;
			this.comboNrButtonsX.Items.AddRange(new object[] {
																 "2",
																 "3",
																 "4",
																 "5",
																 "6",
																 "7",
																 "8",
																 "9",
																 "10"});
			this.comboNrButtonsX.Location = new System.Drawing.Point(160, 24);
			this.comboNrButtonsX.Name = "comboNrButtonsX";
			this.comboNrButtonsX.Size = new System.Drawing.Size(48, 21);
			this.comboNrButtonsX.TabIndex = 7;
			// 
			// btnRemove
			// 
			this.btnRemove.Location = new System.Drawing.Point(256, 96);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(56, 24);
			this.btnRemove.TabIndex = 8;
			this.btnRemove.Text = "Remove";
			this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
			// 
			// listDirectories
			// 
			this.listDirectories.Location = new System.Drawing.Point(8, 16);
			this.listDirectories.Name = "listDirectories";
			this.listDirectories.Size = new System.Drawing.Size(240, 108);
			this.listDirectories.TabIndex = 9;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.chkFitToSize,
																					this.chkAspectRatio});
			this.groupBox1.Location = new System.Drawing.Point(16, 144);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(312, 48);
			this.groupBox1.TabIndex = 9;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Image Rendering";
			// 
			// chkAspectRatio
			// 
			this.chkAspectRatio.Location = new System.Drawing.Point(128, 24);
			this.chkAspectRatio.Name = "chkAspectRatio";
			this.chkAspectRatio.Size = new System.Drawing.Size(104, 16);
			this.chkAspectRatio.TabIndex = 1;
			this.chkAspectRatio.Text = "Aspect Ratio";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.listDirectories,
																					this.btnAdd,
																					this.btnChange,
																					this.btnRemove});
			this.groupBox2.Location = new System.Drawing.Point(16, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(312, 128);
			this.groupBox2.TabIndex = 10;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Directory List";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.chkShowMessageBox,
																					this.optRemove,
																					this.optShow,
																					this.label6,
																					this.txtBackside,
																					this.label5,
																					this.comboSecondsShow,
																					this.comboNrButtonsY,
																					this.comboNrButtonsX,
																					this.label4,
																					this.label3,
																					this.txtNrButtonsY,
																					this.label2});
			this.groupBox3.Location = new System.Drawing.Point(16, 200);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(312, 144);
			this.groupBox3.TabIndex = 11;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Gameplay / Cards";
			// 
			// optShow
			// 
			this.optShow.Location = new System.Drawing.Point(96, 96);
			this.optShow.Name = "optShow";
			this.optShow.Size = new System.Drawing.Size(56, 16);
			this.optShow.TabIndex = 13;
			this.optShow.Text = "show";
			// 
			// btnOK2
			// 
			this.btnOK2.Location = new System.Drawing.Point(96, 352);
			this.btnOK2.Name = "btnOK2";
			this.btnOK2.Size = new System.Drawing.Size(72, 24);
			this.btnOK2.TabIndex = 12;
			this.btnOK2.Text = "OK";
			this.btnOK2.Click += new System.EventHandler(this.btnOK2_Click);
			// 
			// SettingsForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(340, 387);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnOK2,
																		  this.groupBox3,
																		  this.btnCancel,
																		  this.groupBox1,
																		  this.groupBox2});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximumSize = new System.Drawing.Size(350, 416);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(350, 416);
			this.Name = "SettingsForm";
			this.Text = "Memory Game - Settings";
			this.Load += new System.EventHandler(this.SettingsForm_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			//reload values from file
			this.Hide();
			parentForm.Focus();
		}

		private void btnChange_Click(object sender, System.EventArgs e)
		{
			int index = listDirectories.SelectedIndex;

			if (index >= 0 && index < listDirectories.Items.Count) 
			{
				directoryForm.ButtonDone_Text = "Update";
				directoryForm.MyShowDialog((string)listDirectories.Items[index]);	
				if (directoryForm.Choice != null && directoryForm.Choice != "") 
				{ // not canceled
					listDirectories.Items[index] = directoryForm.Choice;
				}
			}
		}

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			directoryForm.ButtonDone_Text = "Add";
			if (listDirectories.Items.Count == 0) 
			{
				directoryForm.MyShowDialog();	
			}
			else 
			{
				directoryForm.MyShowDialog((string)listDirectories.Items[listDirectories.Items.Count-1]);	
			}
			if (directoryForm.Choice != null) // not canceled
			{
				this.listDirectories.Items.Add(directoryForm.Choice);
			}
		}

		private void SettingsForm_Load(object sender, System.EventArgs e)
		{

		}

		private void btnOK2_Click(object sender, System.EventArgs e)
		{
			int nrButtonsX = Int32.Parse(this.comboNrButtonsX.Text);
			int nrButtonsY = Int32.Parse(this.comboNrButtonsY.Text);
			int secondsShow = Int32.Parse(this.comboSecondsShow.Text);

			if ((nrButtonsX * nrButtonsY) % 2 != 0) 
			{
				MessageBox.Show("The number of cards has to be a multiple of 2!",
								"Can't change settings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);				
				return;
			}
			settings.AspectRatio = this.chkAspectRatio.Checked;
			settings.FitToSize = this.chkFitToSize.Checked;
			settings.ButtonText = this.txtBackside.Text;
			settings.NrButtonsX = nrButtonsX;
			settings.NrButtonsY = nrButtonsY;
			settings.SecondsShow = secondsShow;
			settings.FoundPairsRemove = this.optRemove.Checked;
			settings.Dirs = new string[this.listDirectories.Items.Count];
			for (int i = 0; i < this.listDirectories.Items.Count; i++) {
				settings.Dirs[i] = (string)(this.listDirectories.Items[i]);
			}
			settings.ShowPlayerChange = this.chkShowMessageBox.Checked;
			settings.Save();
			this.Hide();
			parentForm.Focus();
		}

		private void btnRemove_Click(object sender, System.EventArgs e)
		{
			int index = listDirectories.SelectedIndex;
			if (index >= 0 && index <= listDirectories.Items.Count) 
			{
				listDirectories.Items.RemoveAt(listDirectories.SelectedIndex);
			}
		}

		public new System.Windows.Forms.Form ParentForm 
		{
			set 
			{
				parentForm = value;
			}
			get 
			{
				return parentForm;
			}
		}
	}
}
