using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace MemoryGame
{
	/// <summary>
	/// Main form for the game - application starts here
	/// </summary>
	public class GameForm : System.Windows.Forms.Form
	{
		// --- constants
		private const string strVersion = "1.0 R2";
		private const int TIMER1_INTERVAL = 750;
		private const int DIST_X = 10;
		private const int DIST_Y = 10;

		private ImageContainer images;
		private string[] imageFilenames;
		private ArrayList buttons; // Spielkarten
		private bool[] buttonOpen;
		private int openButton1 = -1, openButton2 = -1;
		private int[] indexesOfPairs;
		private int secs;
		private int playernr;
		private ArrayList players;
		// config
		private Settings settings = Settings.Load();
		//-------

		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.StatusBar lblStatus;
		private System.Windows.Forms.Panel GamePanel;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.Timer timerRemovePair;
		private System.Windows.Forms.Timer timerSetPairInvisible;
		private System.Windows.Forms.Timer timerSec;
		private System.Windows.Forms.Timer timerPlaySec;
		private System.Windows.Forms.Panel TitlePanel;
		private System.Windows.Forms.MenuItem menuExit;
		private System.Windows.Forms.MenuItem menuAbout;
		private System.Windows.Forms.MenuItem menuOnePlayerGame;
		private System.Windows.Forms.MenuItem menuTwoPlayerGame;
		private System.Windows.Forms.MenuItem menuCustomize;
		private System.Windows.Forms.MenuItem menuRefresh;
		private System.ComponentModel.IContainer components;

		public GameForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GameForm));
			this.timerSec = new System.Windows.Forms.Timer(this.components);
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuCustomize = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuAbout = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuOnePlayerGame = new System.Windows.Forms.MenuItem();
			this.menuTwoPlayerGame = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			this.timerSetPairInvisible = new System.Windows.Forms.Timer(this.components);
			this.timerRemovePair = new System.Windows.Forms.Timer(this.components);
			this.timerPlaySec = new System.Windows.Forms.Timer(this.components);
			this.TitlePanel = new System.Windows.Forms.Panel();
			this.lblStatus = new System.Windows.Forms.StatusBar();
			this.GamePanel = new System.Windows.Forms.Panel();
			this.menuRefresh = new System.Windows.Forms.MenuItem();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.GamePanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// timerSec
			// 
			this.timerSec.Interval = 1000;
			this.timerSec.Tick += new System.EventHandler(this.timerSec_Tick);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 1;
			this.menuItem8.Text = "-";
			// 
			// menuCustomize
			// 
			this.menuCustomize.Index = 0;
			this.menuCustomize.Shortcut = System.Windows.Forms.Shortcut.F12;
			this.menuCustomize.Text = "Customize...";
			this.menuCustomize.Click += new System.EventHandler(this.menuCustomize_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuAbout});
			this.menuItem5.Text = "Help";
			// 
			// menuAbout
			// 
			this.menuAbout.Index = 0;
			this.menuAbout.Text = "About";
			this.menuAbout.Click += new System.EventHandler(this.menuAbout_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 2;
			this.menuItem7.Text = "-";
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuOnePlayerGame,
																					  this.menuTwoPlayerGame,
																					  this.menuItem7,
																					  this.menuExit});
			this.menuItem1.Text = "Game";
			// 
			// menuOnePlayerGame
			// 
			this.menuOnePlayerGame.Index = 0;
			this.menuOnePlayerGame.Shortcut = System.Windows.Forms.Shortcut.F1;
			this.menuOnePlayerGame.Text = "One Player Game";
			this.menuOnePlayerGame.Click += new System.EventHandler(this.menuOnePlayerGame_Click);
			// 
			// menuTwoPlayerGame
			// 
			this.menuTwoPlayerGame.Index = 1;
			this.menuTwoPlayerGame.Shortcut = System.Windows.Forms.Shortcut.F2;
			this.menuTwoPlayerGame.Text = "Two Player Game";
			this.menuTwoPlayerGame.Click += new System.EventHandler(this.menuTwoPlayerGame_Click);
			// 
			// menuExit
			// 
			this.menuExit.Index = 3;
			this.menuExit.Shortcut = System.Windows.Forms.Shortcut.CtrlQ;
			this.menuExit.Text = "Exit";
			this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
			// 
			// timerSetPairInvisible
			// 
			this.timerSetPairInvisible.Interval = 1000;
			this.timerSetPairInvisible.Tick += new System.EventHandler(this.timerSetPairInvisible_Tick);
			// 
			// timerRemovePair
			// 
			this.timerRemovePair.Interval = 1000;
			this.timerRemovePair.Tick += new System.EventHandler(this.timerRemovePair_Tick);
			// 
			// timerPlaySec
			// 
			this.timerPlaySec.Interval = 1000;
			this.timerPlaySec.Tick += new System.EventHandler(this.timerPlaySec_Tick);
			// 
			// TitlePanel
			// 
			this.TitlePanel.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("TitlePanel.BackgroundImage")));
			this.TitlePanel.Cursor = System.Windows.Forms.Cursors.Hand;
			this.TitlePanel.Location = new System.Drawing.Point(128, 64);
			this.TitlePanel.Name = "TitlePanel";
			this.TitlePanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.TitlePanel.Size = new System.Drawing.Size(240, 72);
			this.TitlePanel.TabIndex = 0;
			this.TitlePanel.Click += new System.EventHandler(this.TitlePanel_Click);
			// 
			// lblStatus
			// 
			this.lblStatus.Location = new System.Drawing.Point(0, 529);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(792, 24);
			this.lblStatus.TabIndex = 3;
			this.lblStatus.Text = "Ready";
			// 
			// GamePanel
			// 
			this.GamePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.GamePanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.TitlePanel});
			this.GamePanel.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.GamePanel.Name = "GamePanel";
			this.GamePanel.Size = new System.Drawing.Size(792, 530);
			this.GamePanel.TabIndex = 4;
			this.GamePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.GamePanel_Paint);
			// 
			// menuRefresh
			// 
			this.menuRefresh.Index = 2;
			this.menuRefresh.Shortcut = System.Windows.Forms.Shortcut.F5;
			this.menuRefresh.Text = "Refresh";
			this.menuRefresh.Click += new System.EventHandler(this.menuRefresh_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem10,
																					  this.menuItem5});
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 1;
			this.menuItem10.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuCustomize,
																					   this.menuItem8,
																					   this.menuRefresh});
			this.menuItem10.Text = "Settings";
			// 
			// GameForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 553);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.GamePanel,
																		  this.lblStatus});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "GameForm";
			this.Text = "Memory Game";
			this.GamePanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			GameForm startForm = new GameForm();
			startForm.BackColor = Color.DarkGoldenrod;			
			startForm.TitlePanel.Visible = true;			
			startForm.menuRefresh.Enabled = false;
			Application.Run(startForm);
		}

		private void AddButton(int x, int y, int width, int height) 
		{
			Button button = new Button();
			button.Location = new System.Drawing.Point(x, y);
			button.Name = "button" + buttons.Count;
			button.Size = new System.Drawing.Size(width, height);
			button.TabIndex = 0;
			button.Text = settings.ButtonText;
			button.Click += new System.EventHandler(this.button_Click);
			GamePanel.Controls.Add(button);
			buttons.Add (button);
		}


		private void InitButtons() 
		{
			int x, y;
			int unit_x, unit_y;

			buttons = new ArrayList(settings.NrButtonsX * settings.NrButtonsY);
			unit_x = GamePanel.Width/settings.NrButtonsX;
			unit_y = GamePanel.Height/settings.NrButtonsY;
			for (y = 0; y < settings.NrButtonsY; y++) 
			{
				for (x = 0; x < settings.NrButtonsX; x++) 
				{
					this.AddButton (x*unit_x, y*unit_y, GamePanel.Width/settings.NrButtonsX - DIST_X, GamePanel.Height/settings.NrButtonsY - DIST_Y);
				}
			}
		}

		private void RemoveButtons() 
		{
			if (buttons != null) 
			{
				foreach(Button button in buttons) 
				{	//	for (int i = 0; i < buttons.Count; i++) {
					//      Button button = (Button)buttons[i];	
					GamePanel.Controls.Remove(button);
				}
			}
		}

		private string[] getRandomFilenames(ArrayList filesInDir) 
		{
			int x,y;
			string filename; 
			string[] filenames = new string[settings.NrButtonsY*settings.NrButtonsX];
			int[] idx = getRandomIndexes(filesInDir.Count);

			for (y = 0; y < settings.NrButtonsY; y++) 
			{
				for (x = 0;	x < settings.NrButtonsX; x++) 
				{		
					filename = (string)filesInDir[idx[map(x,y) % idx.Length]];
					filenames[map(x,y)] = filename;
				}
			}
			return filenames;			
		}

		// l�dt Images mit zuf�lligem Dateinamen (aus angegebenem Directory) in den ImageContainer
		private void LoadImages(string[] filenames) 
		{
			Cursor prevCursor;
			int i;
			int nrButtons = settings.NrButtonsX*settings.NrButtonsY;
			int width = GamePanel.Width/settings.NrButtonsX - DIST_X;
			int height = GamePanel.Height/settings.NrButtonsY - DIST_Y;
			string filename;
			//			string dir = this.txtDir.Text;			

			images = new ImageContainer(settings.NrButtonsX * settings.NrButtonsY);

			//			progressBar1.Value = 0;
			//			progressBar1.Maximum = NR_BUTTONS;
			//			progressBar1.Visible = true;
			prevCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;
			for (i = 0; i < nrButtons/2; i++) 
			{
				filename = filenames[i];
				if (settings.FitToSize) 
				{		
					images.AddImageStretched(filename, width, height, settings.AspectRatio);
				}
				else 
				{			
					images.AddImageClipped(filename, width, height);
				}
				lblStatus.Text = "Loading \"" + filename + "\"";
				lblStatus.Refresh();
				//			progressBar1.Value++;
				//			progressBar1.Refresh();
			}
			// images der "doppelg�nger" setzen
			for (i = 0; i < nrButtons/2; i++)
			{
				images.AddImage (images[indexesOfPairs[i]]);
			}
			//			progressBar1.Visible = false;
			this.Cursor = prevCursor;
		}

		private int map(int x, int y) 
		{
			return (y*settings.NrButtonsX + x);
		}

		private void SetButtonImage(int idx, bool visible) 
		{
			Button button;

			button = (Button)buttons[idx];
			if (visible) 
			{
				button.Text = "";
				button.Image = (Image)images[idx];				
			}
			else 
			{
				button.Text = settings.ButtonText;
				button.Image = null;
			}
		}

		private void SetButtonImage(int x, int y, bool visible) 
		{
			SetButtonImage(map(x,y), visible);
		}

		private void SetAllButtonImages(bool visible) 
		{
			int i;
			for (i = 0; i < buttons.Count; i++) 
			{
				SetButtonImage(i, visible);
			}
		}

		private void ClearButtonOpen() 
		{
			for (int i=0; i<buttonOpen.Length; i++) 
			{
				buttonOpen[i] = false;
			}
		}

		private void Swap(ref int value1, ref int value2) 
		{
			int temp;
			temp = value1;
			value1 = value2;
			value2 = temp;
		}

		/// <summary>
		/// array indizes mischen (permutation erstellen)
		/// verwendet in SetPairs und getRandomFilenames
		/// </summary>
		/// <param name="count">
		/// gibt die gr�sse des arrays an, f�r das die indizes erstellt werden
		/// </param>
		/// <returns>
		/// permutation der urspr�nglich aufsteigenden indizes
		/// </returns>
 		private int[] getRandomIndexes(int count) 
		{
			Random randomizer;
			int i, random;
			int[] indexes;

			randomizer = new Random(unchecked((int)DateTime.Now.Ticks));
			indexes = new int[count];

			// aufsteigende indizes generieren
			for (i = 0; i < count; i++) 
			{
				indexes[i] = i;
			}
			// permutation erstellen ("durchmischen")
			for (i = 0; i < count; i++) 
			{
				random = randomizer.Next(count);
				Swap(ref indexes[i], ref indexes[random]);
			}

			return indexes;
		}

		// "doppelg�nger" der images generieren nach zufallsprinzip
		private void SetPairs() 
		{
			int nrButtons = settings.NrButtonsX*settings.NrButtonsY;
			indexesOfPairs = getRandomIndexes(nrButtons/2);
		}

		private System.Collections.ArrayList getFilenames() 
		{
			int i, j;
			ArrayList entries = new ArrayList();
			string[] strEntries;
			for (i = 0; i < settings.Dirs.Length; i++) 
			{
				try 
				{
					strEntries = Directory.GetFiles(settings.Dirs[i]);
					for (j = 0; j < strEntries.Length; j++) 
					{
						if (ImageContainer.isPicture(strEntries[j]))
						{
							entries.Add(strEntries[j]);
						}
					}
				}
				catch (System.IO.DirectoryNotFoundException)
				{
					MessageBox.Show("Directory '" + settings.Dirs[i] + "' does not exist!", "Memory Game",MessageBoxButtons.OK, MessageBoxIcon.Error );
				}
				catch (System.ArgumentException)
				{
					MessageBox.Show("There is no (valid) directory set for images! "
								  + "\n\nChange the settings...", 
									"Memory Game", MessageBoxButtons.OK, 
									MessageBoxIcon.Error);				
				}
			}
			return entries;
		}

		private void TogglePlayers() 
		{
			playernr = (playernr+1) % players.Count;
			DisplayGameStatus();
			if (playernr % 2 != 0) 
			{
				GamePanel.BackColor = Color.BurlyWood;
			}
			else 
			{
				GamePanel.BackColor = Color.DarkSeaGreen;
			}
		}

		private void InitNewGame() 
		{
			System.Collections.ArrayList filenames = getFilenames();
			if (filenames == null || filenames.Count <= 0) 
			{
				MessageBox.Show("There is no (valid) directory set for images! "
		    				    + "\n\nChange the settings...", 
								"Memory Game", MessageBoxButtons.OK, 
					            MessageBoxIcon.Error);
				return;
			}
			else if (filenames.Count < settings.NrButtonsX*settings.NrButtonsY/2) 
			{
				MessageBox.Show("There are not enough images in the given dir(s)! "
				            	+ "\n\nChange the settings...", 
					            "Memory Game", MessageBoxButtons.OK, 
					            MessageBoxIcon.Error);
				return;
			}
			playernr = 0;
			timerRemovePair.Interval = TIMER1_INTERVAL; //ms
			timerRemovePair.Enabled  = false;
			timerSetPairInvisible.Interval = TIMER1_INTERVAL; //ms
			timerSetPairInvisible.Enabled = false;
			timerSec.Interval = 1000; // 1 sec
			timerSec.Enabled = false;
			timerPlaySec.Interval = 1000;
			timerPlaySec.Enabled = false;
			imageFilenames = getRandomFilenames(filenames);
			buttonOpen = new bool[settings.NrButtonsX*settings.NrButtonsY];
			ClearButtonOpen();
			this.RemoveButtons();
			this.TitlePanel.Visible = false;
			this.InitButtons();
			this.SetPairs();
			this.LoadImages(imageFilenames);
			secs = settings.SecondsShow;
			if (secs > 0) 
			{
				SetAllButtonImages(true);
				timerSec.Enabled = true; // macht die bilder wieder unsichtbar
				lblStatus.Text = "Seconds left..." + secs;
				lblStatus.Refresh();				
			}
		}

		private void StartGame() 
		{
			menuRefresh.Enabled = true;
			SetAllButtonImages(false); // bilder wieder unsichtbar (zu beginn)
			timerSec.Enabled = false;
			timerPlaySec.Enabled = true;
		}

		private void EndGame() 		
		{
			string msgBoxStr;

			System.Windows.Forms.DialogResult playagain;
			menuRefresh.Enabled = false;
			timerPlaySec.Enabled = false;
			this.TitlePanel.Visible = true;
			if (players.Count == 1) 
			{
				msgBoxStr = "You passed the game in " + (--((Player)players[0]).Secs) + " secs needing " + ((Player)players[0]).Tries + " tries";
				}
			else if (players.Count == 2) 
			{
				if (((Player)players[0]).FoundPairs > ((Player)players[1]).FoundPairs) 
				{
					msgBoxStr = "-- Winner is " + ((Player)players[0]).Name + " --";
				}
				else if (((Player)players[0]).FoundPairs < ((Player)players[1]).FoundPairs) 
				{
					msgBoxStr = "-- Winner is " + ((Player)players[1]).Name + " --";
				}
				else // gleiche Anzahl an gefundenen Paaren 
				{
					if (((Player)players[0]).Tries < ((Player)players[1]).Tries) 
					{
						msgBoxStr = "-- Winner is " + ((Player)players[0]).Name + " --";
					}
					else if (((Player)players[0]).Tries > ((Player)players[1]).Tries) 
					{
						msgBoxStr = "-- Winner is " + ((Player)players[1]).Name + " --";
					}
					else 
					{
						msgBoxStr = "-- Equal -- Both players have same number of found pairs and tries. --";
					}
				}
				msgBoxStr += "\n" + ((Player)players[0]).Name + ": "
					+ ((Player)players[0]).FoundPairs + " found pairs, " 
					+ ((Player)players[0]).Tries + " tries."
					+ "\n" + ((Player)players[1]).Name + ": "
					+ ((Player)players[1]).FoundPairs + " found pairs, " 
					+ ((Player)players[1]).Tries + " tries.";
			}
			else 
			{
				msgBoxStr = "Internal Error: Unhandled case in EndGame";
			}
			playagain = MessageBox.Show(msgBoxStr +
						   			    "\n\nWanna play again?", 
								        "Memory Game", MessageBoxButtons.YesNo, 
										MessageBoxIcon.Asterisk);

			if (!settings.FoundPairsRemove) // karten noch auf dem spielfeld
			{
				RemoveButtons();
			}
			this.lblStatus.Text = "Select your game...";
			if (playagain == DialogResult.Yes)
			{
				foreach(Player player in players) 
				{	
					player.Init();
				}
				InitNewGame();
			}
			else 
			{
				GamePanel.BackColor = Color.DarkGoldenrod;
			}
		}

		private void menuAbout_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Memory Game version " + strVersion + "\n" 
						  + "(c) Raimund Neum�ller 2002 (Freeware)\n\n"
						  + "written in C# using the Microsoft.NET framework"
						  , "About this game...", MessageBoxButtons.OK, MessageBoxIcon.Information);

		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{

		}

		protected override void OnResize(System.EventArgs e) 
		{
			this.GamePanel.Width = this.Width - 8;
			this.GamePanel.Height = this.Height - 108;
			this.TitlePanel.Top = this.GamePanel.Height/2 - this.TitlePanel.Height/2;
			this.TitlePanel.Left = this.GamePanel.Width/2 - this.TitlePanel.Width/2;
		}

		private void menuOnePlayerGame_Click(object sender, System.EventArgs e)
		{
			players = new ArrayList(1);
			players.Add(new Player("Player 1"));
			InitNewGame();			
		}

		private void menuTwoPlayerGame_Click(object sender, System.EventArgs e)
		{
			players = new ArrayList(2);
			players.Add(new Player("Player 1"));
			players.Add(new Player("Player 2"));
			InitNewGame();			
		}

		// Game/Exit
		private void menuExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void panel2_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{

		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{

		}

		// Settings/Refresh
		private void menuRefresh_Click(object sender, System.EventArgs e)
		{
			int x,y;
			this.RemoveButtons();
			this.InitButtons();
			this.LoadImages(imageFilenames); //dieselben nochmal laden (wg. ge�nderter gr�sse)
			for (y = 0; y < settings.NrButtonsY; y++) 
			{
				for (x = 0; x < settings.NrButtonsX; x++) 
				{
					this.SetButtonImage(x,y,buttonOpen[map(x,y)]);
				}
			}
		}

		// Settings/Customize
		private void menuCustomize_Click(object sender, System.EventArgs e)
		{
			SettingsForm settingsForm = new SettingsForm(settings, this);
			settingsForm.Show();
		}

		private int getButtonNr(object button) 
		{
			int x,y;
			for (y = 0; y < settings.NrButtonsY; y++) 
			{
				for (x = 0; x < settings.NrButtonsX; x++) 
				{
					if (buttons[map(x,y)] == (Button)button)
					{
						return map(x,y);
					}
				}
			}
			return -1;
		}

		// Event-Handler f�r alle Buttons (wird in AddButton registriert)
		private void button_Click(object sender, System.EventArgs e)
		{
			Button button1, button2;
			int buttonNr;
			
			if (timerRemovePair.Enabled || timerSetPairInvisible.Enabled) 
			{
				return; // noch besch�ftigt
			}

			buttonNr = getButtonNr(sender);
			
			if (buttonNr == openButton1) 
			{
				return; // kann nicht die gleiche zweimal aufdecken
			}

			buttonOpen[buttonNr] = !buttonOpen[buttonNr];
			SetButtonImage(buttonNr, buttonOpen[buttonNr]);			

			if (openButton1 == -1) 
			{
				openButton1 = buttonNr;
			}
			else 
			{
				openButton2 = buttonNr;
				button1 = (Button)buttons[openButton1];
				button2 = (Button)buttons[openButton2];
				if (button1.Image == button2.Image) 
				{
					//					MessageBox.Show ("You found a pair");
					this.timerRemovePair.Enabled = true; // erst nach 1 sek. wegnehmen					
				}
				else 
				{
					//					MessageBox.Show ("This is not a pair");
					this.timerSetPairInvisible.Enabled = true; 
				}
				((Player)players[playernr]).Tries++;
			}
		}

		private void timerRemovePair_Tick(object sender, System.EventArgs e)
		{
			Button button1, button2;
			int sumFoundPairs = 0;

			this.timerRemovePair.Enabled = false;
			button1 = (Button)buttons[openButton1]; 
			button2 = (Button)buttons[openButton2];

			if (settings.FoundPairsRemove) 
			{
				GamePanel.Controls.Remove(button1);
				GamePanel.Controls.Remove(button2);
			}
			else
			{
				GamePanel.Controls[GamePanel.Controls.IndexOf(button1)].Enabled = false;
				GamePanel.Controls[GamePanel.Controls.IndexOf(button2)].Enabled = false;
			}
			openButton1 = -1; openButton2 = -1;
			((Player)players[playernr]).FoundPairs++;
			foreach(Player player in players) 
			{
				sumFoundPairs += player.FoundPairs;
			}
			if (sumFoundPairs == (settings.NrButtonsX*settings.NrButtonsY)/2) 
			{
				EndGame();
			}
		}

		// ge�ffnete Buttons nach einer gewissen Zeit (timer gesteuert) 
		// wieder zumachen und ggf. spieler wechseln
		private void timerSetPairInvisible_Tick(object sender, System.EventArgs e)
		{
			this.timerSetPairInvisible.Enabled = false;
			buttonOpen[openButton1] = false;
			buttonOpen[openButton2] = false;
			SetButtonImage(openButton1, false);
			SetButtonImage(openButton2, false);					
			openButton1 = -1; openButton2 = -1;
			this.TogglePlayers();
			if (settings.ShowPlayerChange && players.Count > 1) 
			{
				this.timerPlaySec.Enabled = false;
				MessageBox.Show("Get Ready " + ((Player)players[playernr]).Name, "Memory Game");
				this.timerPlaySec.Enabled = true;
			}
		}

		private void timerSec_Tick(object sender, System.EventArgs e)
		{
			if (secs > 0) 
			{
				secs--;
				lblStatus.Text = "Seconds left..." + secs;
				lblStatus.Refresh();
			}
			else // Start Game
			{
				GamePanel.BackColor = Color.DarkSeaGreen;
				StartGame();
			}
		}

		private void DisplayGameStatus() 
		{
			lblStatus.Text = ">> " + ((Player)players[playernr]).Name + " <<     " 
						   + "Number of tries: " + ((Player)players[playernr]).Tries + ", Time: " + (((Player)players[playernr]).Secs++);
			lblStatus.Refresh();
		}

		private void timerPlaySec_Tick(object sender, System.EventArgs e)
		{
			DisplayGameStatus();
		}

		private void TitlePanel_Click(object sender, System.EventArgs e)
		{
			menuAbout_Click(sender, e);			
		}

		private void GamePanel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{

		}
	}
}
