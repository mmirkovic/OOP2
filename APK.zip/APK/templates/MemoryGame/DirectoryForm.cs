using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace MemoryGame
{
	/// <summary>
	/// Lets you choose a directory via a treelist view
	/// </summary>
	public class DirectoryForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtDirectory;
		private System.Windows.Forms.TreeView listTreeDirs;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Panel panelDoneCancel;
		private System.Windows.Forms.Button btnDone;
		private System.Windows.Forms.Button btnCancel; // designer
		private System.Windows.Forms.Form parentForm = null;
		private System.Windows.Forms.ImageList imglist; // referenz auf parent window

		private string choice = null;
		private System.Windows.Forms.Button btnExplore;
		private System.Timers.Timer timer1;
	
		private enum ImageIndexes 
		{
			computer = 0,
			floppydisk = 1,
			harddisk = 2,
			cdrom = 3,
			directory = 4,
			directory_selected = 5,
			file = 6,
			file_selected = 7
		};
		
		/// <summary>
		///	constructor
		///	Initialize components and ImageList
		///	(other initialisations in myShowDialog..)
		/// </summary>
		public DirectoryForm(Form parentForm)
		{ 
			InitializeComponent(); // Windows Forms designer
			this.parentForm = parentForm;
			// bereits im Form Designer erledigt... Images in imglist abgespeichert
			//			imglist.Images.Add(Image.FromFile("computer.bmp"));
			//			imglist.Images.Add(Image.FromFile("floppydisk.bmp"));
			//			imglist.Images.Add(Image.FromFile("harddisk.bmp"));
			//			imglist.Images.Add(Image.FromFile("cdrom.bmp"));
			//			imglist.Images.Add(Image.FromFile("directory.bmp"));
			//			imglist.Images.Add(Image.FromFile("directory_selected.bmp"));
			//			imglist.Images.Add(Image.FromFile("file.bmp"));
			//			imglist.Images.Add(Image.FromFile("file_selected.bmp"));
			//			this.listTreeDirs.ImageList = imglist;
			//--------------------------------------
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(DirectoryForm));
			this.btnDone = new System.Windows.Forms.Button();
			this.txtDirectory = new System.Windows.Forms.TextBox();
			this.panelDoneCancel = new System.Windows.Forms.Panel();
			this.btnCancel = new System.Windows.Forms.Button();
			this.imglist = new System.Windows.Forms.ImageList(this.components);
			this.timer1 = new System.Timers.Timer();
			this.listTreeDirs = new System.Windows.Forms.TreeView();
			this.btnExplore = new System.Windows.Forms.Button();
			this.panelDoneCancel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			this.SuspendLayout();
			// 
			// btnDone
			// 
			this.btnDone.Location = new System.Drawing.Point(8, 8);
			this.btnDone.Name = "btnDone";
			this.btnDone.Size = new System.Drawing.Size(96, 24);
			this.btnDone.TabIndex = 2;
			this.btnDone.Text = "Done";
			this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
			// 
			// txtDirectory
			// 
			this.txtDirectory.Location = new System.Drawing.Point(16, 8);
			this.txtDirectory.Name = "txtDirectory";
			this.txtDirectory.Size = new System.Drawing.Size(264, 20);
			this.txtDirectory.TabIndex = 0;
			this.txtDirectory.Text = "";
			this.txtDirectory.TextChanged += new System.EventHandler(this.txtDirectory_TextChanged);
			this.txtDirectory.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDirectory_KeyUp);
			// 
			// panelDoneCancel
			// 
			this.panelDoneCancel.Controls.AddRange(new System.Windows.Forms.Control[] {
																						  this.btnDone,
																						  this.btnCancel});
			this.panelDoneCancel.Location = new System.Drawing.Point(56, 280);
			this.panelDoneCancel.Name = "panelDoneCancel";
			this.panelDoneCancel.Size = new System.Drawing.Size(216, 40);
			this.panelDoneCancel.TabIndex = 4;
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(112, 8);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(96, 24);
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// imglist
			// 
			this.imglist.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imglist.ImageSize = new System.Drawing.Size(16, 16);
			this.imglist.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist.ImageStream")));
			this.imglist.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.SynchronizingObject = this;
			// 
			// listTreeDirs
			// 
			this.listTreeDirs.ImageList = this.imglist;
			this.listTreeDirs.Location = new System.Drawing.Point(16, 40);
			this.listTreeDirs.Name = "listTreeDirs";
			this.listTreeDirs.Size = new System.Drawing.Size(304, 232);
			this.listTreeDirs.TabIndex = 1;
			this.listTreeDirs.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.listTreeDirs_AfterExpand);
			this.listTreeDirs.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.listTreeDirs_AfterSelect);
			// 
			// btnExplore
			// 
			this.btnExplore.Image = ((System.Drawing.Bitmap)(resources.GetObject("btnExplore.Image")));
			this.btnExplore.Location = new System.Drawing.Point(288, 8);
			this.btnExplore.Name = "btnExplore";
			this.btnExplore.Size = new System.Drawing.Size(32, 24);
			this.btnExplore.TabIndex = 5;
			this.btnExplore.Tag = "";
			this.btnExplore.Click += new System.EventHandler(this.btnExplore_Click);
			// 
			// DirectoryForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(336, 317);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnExplore,
																		  this.listTreeDirs,
																		  this.txtDirectory,
																		  this.panelDoneCancel});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "DirectoryForm";
			this.Text = "Memory Game - Choose a Directory";
			this.panelDoneCancel.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		protected override void OnResize(System.EventArgs e) 
		{
			this.listTreeDirs.Width = this.Width - 34;
			this.listTreeDirs.Height = this.Height - 100;
			this.txtDirectory.Width = this.Width - btnExplore.Width - 39;
			this.btnExplore.Left = this.Width - btnExplore.Width - 19;
			this.panelDoneCancel.Left = this.Width/2-this.panelDoneCancel.Width/2;
			this.panelDoneCancel.Top = this.listTreeDirs.Top + this.listTreeDirs.Height;
			this.Refresh();
		}

		public string ButtonDone_Text // write-only-property
		{
			set 
			{
				this.btnDone.Text = value;
			}
		}

		private void ShowIOError(Exception e, string path) 
		{
			MessageBox.Show("Could not open \"" + path + "\"\n\n" +
				e.GetBaseException().ToString(), "I/O Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		private void openDirectory(System.Windows.Forms.TreeNode node) 
		{
			System.Windows.Forms.TreeNode subnode = null;
			string[] dirs = null;
			string[] files = null;
			string[] entries = null;
			string strPath;
			int i = 0;
			int nrPics = 0;
			int idx;
			node.Nodes.Clear();
			try 
			{
				strPath = node.FullPath;
				if (strPath.EndsWith(":"))
				{
					strPath += "\\";
				}
				files = Directory.GetFiles(strPath);
				foreach (string file in files) 
				{
					if (ImageContainer.isPicture(file))
					{
						nrPics++;
					}
				}
				subnode = new TreeNode("< " + files.Length + " files, " + nrPics + " pictures >");
				subnode.ImageIndex = (int)ImageIndexes.file;
				subnode.SelectedImageIndex = (int)ImageIndexes.file_selected;
				node.Nodes.Add(subnode);

				dirs = Directory.GetDirectories(strPath);
				entries = new string[dirs.Length];
				for (i = 0; i < dirs.Length; i++) 
				{
					idx = dirs[i].LastIndexOf(@"\") + 1; // nicht immer ganzen pfad adden
					if (idx == 0) 
					{ 
						idx = dirs[i].LastIndexOf(":") + 1; 
					}
					entries[i] = dirs[i].Substring(idx, dirs[i].Length - idx);
				}
				System.Array.Sort(entries);
				for (i = 0; i < entries.Length; i++) 
				{
					subnode = new TreeNode(entries[i]);
					subnode.ImageIndex = (int)ImageIndexes.directory;
					subnode.SelectedImageIndex = (int)ImageIndexes.directory_selected;
					node.Nodes.Add(subnode);
				}
			}
			catch (System.IO.IOException e) 
			{
				if (dirs != null && i > 0) 
					ShowIOError(e, dirs[i-1]);
				else
					ShowIOError(e, node.FullPath);
			}
		}

		public void MyShowDialog() 
		{
			MyShowDialog(null);
		}

		public void MyShowDialog(string initial_path) 
		{			
			string[]drives;
			System.Windows.Forms.TreeNodeCollection root;
			System.Windows.Forms.TreeNode node;

			this.listTreeDirs.Nodes.Clear();
			drives = Directory.GetLogicalDrives();

			root = this.listTreeDirs.Nodes; // root
			this.listTreeDirs.BeginUpdate();
			for (int i = 0; i < drives.Length; i++) 
			{
				node = new TreeNode(drives[i].Substring(0, drives[i].Length-1));
				node.Nodes.Add("<empty>"); // nur, dass '+' angezeigt wird
				if (node.Text == "A:" || node.Text == "B:")
				{
					node.ImageIndex = (int)ImageIndexes.floppydisk;
					node.SelectedImageIndex = (int)ImageIndexes.floppydisk;
				}
				else 
				{
					node.ImageIndex = (int)ImageIndexes.harddisk;
					node.SelectedImageIndex = (int)ImageIndexes.harddisk;
				}
				root.Add(node);
			}
			this.listTreeDirs.EndUpdate();

			if (initial_path != null)
			{   
				ExpandToPath(initial_path);
			}
			this.ShowDialog();
		}

		private void AddEntry(ArrayList entries, string entry) 
		{
			if (entry.EndsWith(":\\")) 
			{ // driveletter, z.B. "F:" statt "F:\"
				entry = entry.Substring(0, entry.Length-1);
			}
			entries.Add(entry);
		}

		private ArrayList TokenizePath(string path) 
		{
			ArrayList entries = new ArrayList();
			int j = 0;
			for (int i=0; i < path.Length; i++) 
			{
				if (((path[i] == '\\') || (i == path.Length-1))&& (j > 0) && (i > 1)) 
				{
					if (i == path.Length-1) 
					{
						AddEntry(entries, path.Substring(i-j, j+1));
					}
					else 
					{ // path[i] = '\\'
						AddEntry(entries, path.Substring(i-j, j));
					}
					j = 0;
				}
				else 
				{
					j++;
				}
			}
			string lastEntry = (string)entries[entries.Count-1];
			if (lastEntry.EndsWith("\\"))
			{ // letzter entry darf nicht mit "\" enden
				entries[entries.Count-1] = lastEntry.Substring(0, lastEntry.Length-1);
			}
			return entries;
		}

		private string getValidPath(string path) 
		{
			int idx;
			if (path == null || path == "") 
			{
				return null;
			}
			idx = path.IndexOf(":");
			if (idx == -1) 
			{
				return null;
			}
			if (idx != path.Length-1 && path[idx+1] != '\\') 
			{
				return (path.Substring(0, idx+1) + "\\" + path.Substring(idx+1,path.Length-idx-1));
			}		
			return path;
		}

		private void ExpandToPath(string path) 
		{
			if ((path = getValidPath (path)) != null) 
			{
				ArrayList entries = TokenizePath(path);
				TreeNodeCollection nodes = listTreeDirs.Nodes;
				TreeNode node;
				listTreeDirs.CollapseAll();
				for (int i=0; i<entries.Count; i++) 
				{ // �ffnen der knoten simulieren					
					node = FindNode(nodes, (string)entries[i]);
					if (node != null) 
					{
						node.Expand();
						//				listTreeDirs.SelectedNode = node;
						listTreeDirs_AfterExpand(this, new TreeViewEventArgs(node));			
						nodes = node.Nodes;
					}
					else 
					{
						MessageBox.Show("The directory '" + (string)entries[i] + "' could not be found!"
									  + "\n\nPath: " + path,
									    "Memory Game",
							            MessageBoxButtons.OK,
										MessageBoxIcon.Exclamation);
					}
				}
				listTreeDirs.Refresh();
			}
		}

		private TreeNode FindNode(TreeNodeCollection nodes, string text) 
		{
			foreach (TreeNode node in nodes) 
			{
				if (node.Text.Equals(text)) 
				{
					return node;
				}
			}
			// nicht gefunden
			return null;
		}

		public string Choice 
		{
			get 
			{
				return choice;
			}
		}

		private void listTreeDirs_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e) 
		{
			System.Windows.Forms.TreeNode node;
			node = this.listTreeDirs.SelectedNode;
			if (node.Text.StartsWith("<"))
			{ // <.. d.h. kein directory
				this.txtDirectory.Text = node.Parent.FullPath;
			}
			else 
			{
				this.txtDirectory.Text = node.FullPath;
			}
		}

		private void listTreeDirs_AfterExpand(object sender, System.Windows.Forms.TreeViewEventArgs e) 
		{
			int i = 0;
			System.Windows.Forms.TreeNode node;
			System.Windows.Forms.TreeNode subnode;

			node = e.Node;
			this.listTreeDirs.BeginUpdate();
			this.txtDirectory.Text = node.FullPath;

			if (node.Text.EndsWith(":")) 
			{ // Logical drive kann nicht im vorhinein aufgemacht werden
				openDirectory(node);				
			}
			for (i = 0; i < node.Nodes.Count; i++) 
			{ // subknoten mit directories f�llen
				subnode = node.Nodes[i];
				if (!subnode.Text.StartsWith("<")) 
				{
					openDirectory(subnode);
				}
			}
			this.listTreeDirs.EndUpdate();
			this.listTreeDirs.Refresh();
		}

		private void MyHide() 
		{
			this.Hide();
			//			parentForm.ParentForm.Focus();
			parentForm.Focus();
		}

		private void btnDone_Click(object sender, System.EventArgs e)
		{
			choice = this.txtDirectory.Text;
			MyHide();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.txtDirectory.Text = "";
			choice = "";
			MyHide();
		}

		private void txtDirectory_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == System.Windows.Forms.Keys.Return) 
			{
				string path = txtDirectory.Text;
				txtDirectory.Text = "";
				ExpandToPath(path);
			}
		}

		private void btnExplore_Click(object sender, System.EventArgs e)
		{
			string directory = this.txtDirectory.Text;
			System.Diagnostics.Process myProcess = new Process();
			myProcess.StartInfo.FileName = "explorer.exe";
			myProcess.StartInfo.Arguments = directory;
			myProcess.Start();
		}

		private void txtDirectory_TextChanged(object sender, System.EventArgs e)
		{

		}

		public new System.Windows.Forms.Form ParentForm 
		{
			set 
			{
				parentForm = value;
			}
			get 
			{
				return parentForm;
			}
		}
	}
}
