using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace MemoryGame
{	
	// Laden und Speichern der Konfiguration
	[Serializable]
	public class Settings
	{
		private const string default_filename = "MemoryGame.cfg";

		private bool fit_to_size;
		private bool aspect_ratio;
		private int nr_buttons_x;
		private int nr_buttons_y;
		private int seconds_show;
		private bool found_pairs_remove;
		private string button_text;
		private string[] dirs;
		private bool show_player_change;

		public Settings()
		{
			this.setDefaultValues();
		}

		public void setDefaultValues() 
		{
			fit_to_size = false;
			aspect_ratio = false;
			nr_buttons_x = 4;
			nr_buttons_y = 3;
			seconds_show = 3;
			found_pairs_remove = false;
			button_text = "Memory";
			show_player_change = true;
		}
		public static Settings Load(string path) 
		{
			try 
			{
				FileStream s = new FileStream(path, FileMode.Open);
				IFormatter f = new BinaryFormatter();
				Settings loadedSettings = f.Deserialize(s) as Settings;
				s.Close();
				return loadedSettings;		
			}
			catch (FileNotFoundException e) 
			{
				string fault = e.GetBaseException().ToString();
				return new Settings();
			}			
		}
		public bool Save(string path)
		{
			try 
			{
				FileStream s = new FileStream(path, FileMode.Create);
				IFormatter f = new BinaryFormatter();
				f.Serialize(s, this);
				s.Close();				
				return true;
			}
			catch (IOException) 
			{
				return false;
			}
		}
		public static Settings Load() 
		{
			string default_path;
			default_path = Directory.GetCurrentDirectory();
			return Load(default_path + "\\" + default_filename);
		}
		public bool Save()
		{
			string default_path;
			default_path = Directory.GetCurrentDirectory();
			return Save(default_path + "\\" + default_filename);
		}

		public bool FitToSize 
		{
			set 
			{
				fit_to_size = value;
			}
			get 
			{
				return fit_to_size;
			}
		}
		public bool AspectRatio 
		{
			set
			{
				aspect_ratio = value;
			}
			get 
			{
				return aspect_ratio;
			}
		}
		public int NrButtonsX
		{
			set
			{
				nr_buttons_x = value;
			}
			get 
			{
				return nr_buttons_x;
			}
		}
		public int NrButtonsY 
		{
			set 
			{
				nr_buttons_y = value;
			}
			get 
			{
				return nr_buttons_y;
			}
		}
		public int SecondsShow 
		{
			set 
			{
				seconds_show = value;
			}
			get 
			{
				return seconds_show;
			}
		}
		public string ButtonText 
		{
			set
			{
				button_text = value;
			}
			get 
			{
				return button_text;
			}
		}
		public bool FoundPairsRemove 
		{
			set
			{
				found_pairs_remove = value;
			}
			get
			{
				return found_pairs_remove;
			}
		}
		public string[] Dirs
		{
			set 
			{
				dirs = value;
			}
			get 
			{
				return dirs;
			}
		}
		public bool ShowPlayerChange 
		{
			set 
			{
				show_player_change = value;
			}
			get 
			{
				return show_player_change;
			}
		}
	}
}
