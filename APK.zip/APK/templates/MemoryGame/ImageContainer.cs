using System;
using System.Runtime.InteropServices; // f�r Native Calls
using System.Drawing;
using System.Collections;
using System.Windows.Forms; // MessageBox

namespace MemoryGame
{
	/// <summary>
	/// Summary description for ImageContainer.
	/// </summary>
	public class ImageContainer
	{
		// GDI-Funktionen (Native Calls) f�r Stretchen der Bitmaps
		//---------------------------------------------------------
		private const int SRCCOPY = 0xCC0020; // (DWORD) dest = source

		[DllImport("gdi32.dll")]
		static extern int CreateCompatibleDC(int refDC);
		[DllImport("gdi32.dll")]
		static extern int DeleteDC(int HDC);
		[DllImport("gdi32.dll")]
		static extern int SelectObject(int HDC, int hObject);
		[DllImport("gdi32.dll")]
		static extern int DeleteObject(int hObject);
		[DllImport("gdi32.dll")]
		static extern int BitBlt(
			int hdcDest, int nXOriginDest, int nYOriginDest,
			int nWidthDest, int nHeightDest,
			int hdcSrc, int nXOriginSrc, int nYOriginSrc, int dwRop);
		[DllImport("gdi32.dll")]
		static extern int CreateCompatibleBitmap(int refDC, int nWidth, int nHeight);
		[DllImport("user32.dll")]
		static extern int GetDC(int hWnd);
		[DllImport("user32.dll")]
		static extern int ReleaseDC(int hWnd, int hDC);
//		[DllImport("gdi32.dll")]
//		static extern int StretchBlt(
//			int hdcDest, int nXOriginDest, int nYOriginDest,
//			int nWidthDest, int nHeightDest,
//			int hdcSrc, int nXOriginSrc, int nYOriginSrc,
//			int nWidthSrc, int nHeightSrc, int dwRop);
//		[DllImport("gdi32.dll")]
//		static extern int SetStretchBltMode(int hdc, int iStretchMode);
		[DllImport("kernel32.dll")]
		static extern uint GetLastError();
		//----- GDI-Funktionen ENDE ----------------------------------

		private System.Collections.ArrayList data;
		private static string[] picsuffix = {"bmp", "jpg", "jpeg", "gif"};

		public static bool isPicture(string filename) 
		{
			int i;

			if (filename == null) 
			{
				return false;
			}

			for (i = 0; i < picsuffix.Length; i++) 
			{
				if (filename.EndsWith(picsuffix[i])) 
				{
					return true;
				}
			}
			return false;
		}

		public ImageContainer()
		{
			//
			// TODO: Add constructor logic here
			//
			data = new ArrayList();
		}
		// vorreservierter speicherplatz (siehe ArrayList)
		public ImageContainer(int capacity) 
		{
			data = new ArrayList(capacity);
		}

		public Image this[int index] 
		{
			get 
			{
				return (Image)data[index];
			}
		}

		// foreach-Anweisung benutzt diese Methode
		public MyEnumerator GetEnumerator() 
		{
			return new MyEnumerator(this);
		}

		// Declare the enumerator class:
		public class MyEnumerator 
		{
			int nIndex;
			ImageContainer collection;
			public MyEnumerator(ImageContainer coll) 
			{
				collection = coll;
				nIndex = -1;
			}

			public bool MoveNext() 
			{
				nIndex++;
				return(nIndex < collection.Count);
			}

			public Image Current 
			{
				get 
				{
					return(collection[nIndex]);
				}
			}
		}

		// Methode mit Native Calls
		// Kopieren eines Ausschnittes
		private Image ClipImage(Image source, int nDestWidth, int nDestHeight, int x, int y) 
		{
			Image image;
			Bitmap bitmap;
			int hbitmap1, hbitmap2; 
			int hDC1, hDC2, screenDC; 
			int res;

			// Konvertierung Image-Objekt -> 32 bit handle ------
			//			bitmap = new Bitmap(source);
			bitmap = (Bitmap)source;
//			hbitmap1 = bitmap.GetHbitmap().ToInt32(); 
			hbitmap1 = (int)bitmap.GetHbitmap();  // w�hlt richtige int-funktion aus
			// Kopieren mittels BitBlt (GDI Funktionen) ---------
			hDC1 = CreateCompatibleDC(0);
			res = SelectObject(hDC1, hbitmap1);
			hDC2 = CreateCompatibleDC(0);
			screenDC = GetDC(0);
			hbitmap2 = CreateCompatibleBitmap(screenDC, nDestWidth, nDestHeight);
			res = SelectObject(hDC2, hbitmap2);	
			res = BitBlt(hDC2, x, y, nDestWidth, nDestHeight, hDC1, 0, 0, SRCCOPY);
			// R�ckkonvertierung 32 bit handle -> Image-Objekt -- 				 
			image = Image.FromHbitmap(new IntPtr(hbitmap2));
			// Freigeben von GDI-Resourcen ----------------------
			res = DeleteObject(hbitmap1);
			res = DeleteObject(hbitmap2);
			res = DeleteDC(hDC1);
			res = DeleteDC(hDC2);
			res = ReleaseDC(0, screenDC);
			// neues Image-Objekt
			return image;
		}

		private Image ClipImage(Image source, int nDestWidth, int nDestHeight) 
		{
			return ClipImage(source, nDestWidth, nDestHeight, 0, 0);
		}

		public int Count // property
		{
			get { return data.Count; }
		}

		// Ber�cksichtigung H�he/Breitenverh�ltnis
		private void CalcImageSize(int sourceWidth, int sourceHeight, int nDestWidth, int nDestHeight, out int destWidth, out int destHeight) 
		{
			if (sourceWidth > sourceHeight) 
			{
				destWidth = nDestWidth;
				destHeight = nDestHeight / (sourceWidth / nDestWidth);
			}
			else 
			{	
				destWidth = nDestWidth / (sourceHeight / nDestHeight);
				destHeight = nDestHeight;
			}
		}

		public void AddImage(Image item) 
		{
			data.Add(item);
		}
		public void AddImageClipped(Image source, int nDestWidth, int nDestHeight) {
			Image destImage;
			destImage = ClipImage(source, nDestWidth, nDestHeight);
//			System.Drawing.Graphics g;
//			destImage = new Bitmap(nDestWidth, nDestHeight);
//			g = System.Drawing.Graphics.FromImage(destImage);
//			g.DrawImageUnscaled( source, 0,0,nDestWidth, nDestHeight);			
			data.Add(destImage);
		}
		public void AddImageStretched(Image source, int nDestWidth, int nDestHeight, bool aspectRatio) 
		{
			Image destImage;
			int destWidth, destHeight;
			System.Drawing.Graphics g;
			destImage = source;
			if (aspectRatio) 
			{
				CalcImageSize(source.Width, source.Height, nDestWidth, nDestHeight, out destWidth, out destHeight);
			}
			else 
			{
				destWidth = nDestWidth; destHeight = nDestHeight;
			}
			destImage = new Bitmap(destWidth, destHeight);
			g = System.Drawing.Graphics.FromImage(destImage);
			g.DrawImage(source, 0,0,destWidth, destHeight);
			data.Add(destImage);
		}
		public void AddImage(string filename) 
		{
			Image source;			
			source = Image.FromFile(filename);
			this.AddImage(source);
		}
		public void AddImageClipped(string filename, int nDestWidth, int nDestHeight) 
		{
			Image source;			
			try 
			{
				source = Image.FromFile(filename);
				this.AddImageClipped(source, nDestWidth, nDestHeight);
			}
			catch (System.OutOfMemoryException e)
			{
				MessageBox.Show("Could not open \"" + filename + "\"\n\n" +
					e.GetBaseException().ToString(), "I/O Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		public void AddImageStretched(string filename, int nDestWidth, int nDestHeight, bool aspectRatio) 
		{
			Image source;
			try 
			{
				source = Image.FromFile(filename);
				this.AddImageStretched(source, nDestWidth, nDestHeight, aspectRatio);
			}
			catch (System.OutOfMemoryException e)
			{
				MessageBox.Show("Could not open \"" + filename + "\"\n\n" +
					e.GetBaseException().ToString(), "I/O Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

			}
		}
	}
}
