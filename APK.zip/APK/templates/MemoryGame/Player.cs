using System;

namespace MemoryGame
{
	/// <summary>
	/// Summary description for Player.
	/// </summary>
	public class Player
	{
		private int tries;
		private int secs;
		private int foundPairs;
		private string name;

		public int Tries 
		{
			get 
			{
				return tries;
			}
			set 
			{
				tries = value;
			}
		}

		public int Secs
		{
			get 
			{
				return secs;
			}
			set 
			{
				secs = value;
			}
		}

		public int FoundPairs 
		{
			get 
			{
				return foundPairs;
			}
			set 
			{
				foundPairs = value;
			}
		}

		public string Name 
		{
			get 
			{
				return name;
			}
			set 
			{
				name = value;
			}
		}

		public void Init() 
		{
			tries = 0;
			foundPairs = 0;
			secs = 0;
		}

		public Player() : this("player")
		{
		}

		public Player(string name) 
		{
			this.name = name;
			Init();
		}
	}
}
